/*     YASC.c - Yet Another SETI@Home Controller.
 *     Copyright (C) 2000, 2002 Erik Forsberg
 *     forsberg@lysator.liu.se
 *
 *     Extended to v0.03 by Stanislav Sokolov (stanislavs@hotmail.com)
 *
 *     This program is free software; you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation; either version 2 of the License, or
 *     (at your option) any later version.
 *
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 *
 *     You should have received a copy of the GNU General Public License
 *     along with this program, see the file COPYING; if not, write
 *     to the Free Software Foundation, Inc., 675 Mass Ave, Cambridge,
 *     MA 02139, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <signal.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <ctype.h>
#include <errno.h>
#include <time.h>

#define VERSION "0.03"

struct clients {
  char *path;
  char *name;
  char params[256];
  unsigned int pid;
  struct clients *next;
};

int verbose;
struct clients *cl_glob;

struct device {
  char *name;
  unsigned long lastread;
  int changed;
  int count;
  struct device *next;
};

extern char **environ;

void run(struct clients *c)
{
  char *params[32] = {NULL};
  int i = 0;
  char *prm = c->params;
  
  if (chdir(c->path) == -1) {
    perror("chdir");
    exit(1);
  }

  /* Build parameter list */
  params[i++] = c->name;

  while(*prm != '\0'){
    while(isspace(*prm) && *prm != '\0')
      prm++;

    if(*prm == '\0')
      break;

    params[i++] = prm++;
    
    while(!isspace(*prm) && *prm != '\0')
      prm++;
    
    if(*prm != '\0'){
      *prm = '\0';
      prm++;
    }
  }
  params[i] = NULL;

  execve(c->name, params, environ);
  perror("execv");
  exit(2);
}


void procFatal(const char* msg){
  printf("\nCouldn't open %s - are you sure you have /proc filesystem support?", msg);
  exit(1);
}

void usage(char *progname){
  printf("\nUsage: %s [OPTIONS] <path/prog1> <path/prog2> ...\n", progname);
  printf("Run one or more SETI@Home processes after a configurable amount of time by\n"
	 "monitoring several conditions: idle time at the keyboard or mouse (or\n"
	 "any other device that has an entry in /proc/interrupts); a suitable system\n"
	 "load; other users looged in on the system.\n\n");
  printf(" -a\t\tKeep the clients alive.\n");
  printf(" -d dev[:count]\tDevice to watch. Count is the number of interrupts before\n"
	 "\t\tthe device is considered not to be idle.\n"
	 "\t\tPass several -d to watch several devices\n");
  printf(" -i sec\t\tTime to pass before running client(s) in seconds.\n");
  printf(" -l min:max\tMonitor system load. Start clients if less that min, kill or\n"
	 "\t\tsuspend if over max. The values are floats. E.g.: -l 0.85:2.1\n");
  printf(" -s\t\tSuspend processes insead of killing them.\n");
  printf(" -u\t\tCheck for other logged-in users.\n");
  printf(" -v\t\tBe verbose.\n");
  printf(" -h\t\tShow this text.\n");
  printf("\n");
}


struct clients *fillinClients(int startidx, int endidx, char **argv){
  struct clients *p, *d;
  FILE *f;
  char buf[256];
  int i;
  char *tmp;

  p = d = NULL;

  for(; startidx<=endidx; startidx++) {
    if (p == NULL) {
      p = (struct clients *)malloc(sizeof(struct clients));
      p->next = NULL;
      d = p;
    }
    else {
      d = (struct clients *)malloc(sizeof(struct clients));
      d->next = p;
      p = d;
    }

    tmp = strrchr(argv[startidx-1], '/');

    p->pid = 0;

    if(tmp == NULL){
      printf("\nERROR: Full or relative path to client expected (e.g.: ./setiathome)\n"
	     "along with the client's name.\n\n");
      usage(argv[0]);
      exit(1);
    }

    *tmp = '\0';
    p->path = argv[startidx-1];
    p->name = tmp + 1;


    /* Try to read parameters from file */
    strcpy(buf, p->path);
    strcat(buf, "/.yascrc");
    if((f = fopen(buf, "r")) != NULL){
      fgets(p->params, 127, f);
      fclose(f);
      i = strlen(p->params) - 1;
      if(p->params[i] == '\n') /* Remove trailing newline if present */
	p->params[i] = '\0';
    }else
      p->params[0] = '\0';
  }
  return p;
}

struct device *newDevice(char *name, struct device *d)
{
  struct device *t;
  char *col;
  if (d == NULL) {
    d = (struct device *)malloc(sizeof (struct device));
    d -> next = NULL;
    t = d;
  }
  else {
    t = (struct device *)malloc(sizeof (struct device));
    t -> next = d;
    d = t;
  }

  /* Parse threshold counter */
  col = strchr(name, ':');
  if(col == NULL){
    d -> name = name;
    d -> count = 1;
  }else{
    *col = '\0';
    d -> name = name;
    d -> count = atoi(col+1);
  }

  d -> lastread = 0;
  d -> changed = 0;

  return d;
}

int getNrofProcessors(void) 
{
  int ret = 0;
  char *ch;
  FILE *fp;
  char line[85];
  fp = fopen("/proc/cpuinfo", "r");
  if (fp == NULL)
    procFatal("/proc/cpuinfo");

  while(fgets(line, 85, fp) != NULL) {
    if (strstr(line, "processor") != NULL) {
      ch = strchr(line, ':');
      ch++;
      ret = atoi(ch);
    }
  }
  fclose(fp);
  return ret + 1;
}

int updateReadings(struct device *d, int nrof_processors){
  char *ch;
  FILE *fp;
  int i;
  int isUpdated = 0;
  struct device *base;
  unsigned long reading;
  char line[1024]; /* Support _MANY_ processors :) */
  fp = fopen("/proc/interrupts", "r");

  if (fp == NULL)
    procFatal("/proc/interrupts");

  while(fgets(line, 1024, fp) != NULL) {
    base = d;
    while (base != NULL) {
      if (strstr(line, base->name) == NULL) {
	base = base->next;
	continue;
      }
      ch = strchr(line, ':');
      ch++;
      reading = atol(ch);
      if (nrof_processors > 1)
	for(i=1;i<nrof_processors;i++) {
	  while(*ch == ' ')
	    ch++;
	  while(*ch != ' ')
	    ch++;
	  reading += atol(ch);
	}
 
      if (reading > base->lastread + base->count) {
	base->changed = 1;
	isUpdated = 1;
      }
      else
	base->changed = 0;

      base->lastread = reading;
      if(verbose)
	printf("YASC: Device %s had reading %lu -%s updated\n", base->name, 
	       reading, base->changed ? "" : " not");
      base = base->next;
    }
  }
  fclose(fp);
  return isUpdated;
}


/* Taken with modifications from get_load.c from xload project */
double getLoadPoint(void){
  static int fd = -1;
  int n;
  char buf[32];

  if (fd < 0){
    if (fd == -2 || (fd = open("/proc/loadavg", O_RDONLY)) < 0)
      procFatal("/proc/loadavg");
  }else
    lseek(fd, 0, 0);

  if ((n = read(fd, buf, sizeof(buf)-1)) > 0){
    if(verbose)
      printf("YASC: load = %f\n", atof(buf));
    return atof(buf);
  }

  return 0.0;
}

int parseLoad(const char *data, double *lmin, double *lmax){
  double tmp;
  char *col = strchr(data, ':');
  if(col == NULL)
    return 0;

  *lmin = strtod(data, &col);
  *lmax = strtod(col + 1, NULL);

  /* Check for illigal values */
  if(*lmin <= 0.0 || *lmax <= 0.0)
    return 0;

  /* Let's be foolproof :) */ 
  if(*lmin > *lmax){
    tmp = *lmax;
    *lmax = *lmin;
    *lmin = tmp;
  }

  if(verbose)
    printf("Load restrictions enabled: start below %f, stop above %f.\n", *lmin, *lmax);
 
  return 1;
}


void keepAlive(struct clients *c){
  int alive;
  pid_t pid, ret;

  while(c != NULL){
    errno = 0;
    ret = waitpid(c->pid, &alive, WNOHANG);

    if(ret == -1 && errno == ECHILD){
      if(verbose)
	printf("YASC: Dead client detected - restarting...\n");
      
      /* This client is dead, re-run it */
      pid = fork();
      if (pid != 0) {
	c->pid = pid;
      }else 
	run(c);
    }
    c = c->next;
  }
}

/* Check if other users than the initiator are logged in the system.
 * Useful for remote login systems.
 */
int otherUsers(void){
  char file[32];
  char cmd[32];
  char line[1024];
  FILE *fin;
  char *tmp;
  static char *user = NULL;

  if(user == NULL)
    user = getenv("USER");
  
  sprintf(file, "/tmp/yascuse-%04X.tmp", rand() & 0xFFFF);
  sprintf(cmd, "users > %s", file);

  system(cmd);

  if((fin = fopen(file, "r")) == NULL){
    return 0;
  }
  
  if((fgets(line, 1023, fin)) == NULL){
    fclose(fin);
    unlink(file);
    return 0;
  }

  fclose(fin);
  unlink(file);

  if(line[strlen(line) - 1] == '\n')
    line[strlen(line) - 1] = '\0';

  tmp = strtok(line, " ");
  while(tmp != NULL){
    if(strcmp(user, tmp) != 0){
      if(verbose)
	printf("YASC: Other users logged in...\n");
      return 1;
    }
    tmp = strtok(NULL, " ");
  }

  return 0;
}

/* Checks for other instances of YASC */
void checkYASC(char *progname, struct clients *cl){
  char file[512], cmd[512], filelock[512], name[128], line[1024];
  FILE *fin, *flock;
  pid_t pid;
  struct clients *tc;

  if(verbose)
    fprintf(stderr, "Checking and aquiring locks... ");
  
  sprintf(file, "/tmp/yascuse-%04X.tmp", rand() & 0xFFFF);
  sprintf(cmd, "ps x > %s", file);

  system(cmd);

  if((fin = fopen(file, "r")) == NULL){
    unlink(file);
    return;
  }
 
  /* Go through all client paths and check for lock files */
  tc = cl;
  while(tc != NULL){
    sprintf(filelock, "%s/.yasc.lock", tc->path);
    if((flock = fopen(filelock, "r")) != NULL){  /* Found a lock - deal with it */
      /* Check if another YASC is still running */
      fscanf(flock, "%d %s", &pid, name);
      
      while(fgets(line, 1023, fin) != NULL){
	if(atoi(line) == pid){ /* We have same pid running */
	  if(strstr(line, progname) != NULL){ /* And it has the same name, hmm... */ 
	    if(verbose)
	      printf("\nFound \"%s\" with PID %d serving client in %s -- Aborting!\n", 
		     progname, pid, cl->path);
	    fclose(flock);
	    fclose(fin);
	    unlink(file);
	    exit(5);
	  }
	}
      }
      rewind(fin);
    } /* if */
    tc = tc->next;
  } /* while(cl ... ) */

  fclose(fin);
  unlink(file);

  /* Grab locks (race condition is possible) */
  tc = cl;
  while(tc!= NULL){
    sprintf(filelock, "%s/.yasc.lock", tc->path);
    if((flock = fopen(filelock, "w+t")) == NULL){
      fprintf(stderr, "\nFailed to aquire lock!\n");
      exit(6);
    }
    fprintf(flock, "%d %s\n", getpid(), progname);
    fclose(flock);
    
    tc = tc->next;
  }/* while */

  if(verbose)
    printf("done.\n");

}

/* Clean-up routine invoked at shut-down */
void sighdl(int sig){
  struct clients *tc = cl_glob;
  char file[512];

  if(verbose)
    fprintf(stderr, "YASC: Cleaning up and exiting.\n");

  while(tc != NULL){
    if(tc->pid != 0){
      kill(tc->pid, SIGCONT);
      kill(tc->pid, SIGTERM);
      wait(NULL); /* Hocus Pocus to prevent <defunct> processes */
    }

    sprintf(file, "%s/.yasc.lock", tc->path);
    unlink(file);
    
    tc = tc->next;
  }

  exit(0);
}


int main(int argc, char **argv){
  unsigned int idletime = 120;
  int suspend = 0, keepalive = 0, load = 0, users = 0,  runcond; /* Action flags */
  double lmin = 0.0, lmax = 0.0;
  int nrof_processors = 0;
  struct clients *c = NULL;
  struct clients *tc = NULL;
  struct device *d = NULL;
  pid_t pid = 0;
  int ch;
  verbose = 0;
  printf("YASC %s by Erik Forsberg <forsberg@lysator.liu.se> and\n"
	 "             Stanislav Sokolov <stanislavs@hotmail.com>\n", VERSION);
  if (argc < 2) {
    usage(argv[0]);
    return -1;
  }

  while ((ch = getopt(argc, argv, "i:vd:hl:sau")) != -1) {
    switch(ch) {
    case (int)'i':
      idletime = atoi(optarg);
      break;
    case (int)'v':
      verbose = 1;
      break;
    case (int)'d':
      d = newDevice(optarg, d);
      break;
    case (int)'h':
      usage(argv[0]);
      return -1;
    case (int)'l':
      load = parseLoad(optarg, &lmin, &lmax);
      break;
    case (int)'s':
      suspend = 1;
      break;
    case (int)'a':
      keepalive = 1;
      break;
    case (int)'u':
      users = 1;
      break;
    default:
      printf(".\n");
      return -1;
    }
  }

  if (optind == argc) {
    printf("No clients specified! Nothing to do!\n");
    return -1;
  }

  if(idletime == 0) {
    printf("I parse your idletime argument to 0 seconds - I only \n"
	   "understand idletimes of 1 second or more");
    return -1;
  }

  cl_glob = c = fillinClients(optind+1, argc, argv);

  checkYASC(argv[0], c);

  /* Install signal handler for clean-up at shut-down */
  signal(SIGTERM, sighdl);
  signal(SIGINT, sighdl);

  nrof_processors = getNrofProcessors();

  if (verbose) {
    printf("Will execute SETI@home clients in the following dirs:\n");
    tc = c;
    while(tc!=NULL) {
      printf("%s/%s %s\n", tc->path, tc->name, tc->params);
      tc = tc->next;
    }
    printf("You seem to have %d processor%s.\n", nrof_processors, nrof_processors > 1 ? "s" : "");
    printf("I will wait for %d second%s before executing clients.\n", idletime, idletime > 1 ? "s" : "");
  }

  srand(time(NULL)); /* Needed by otherUsers() */

  for(;;){
    /* Check for changes - start condition */
    do{
      sleep(idletime);
      runcond = 1; /* Optimistic start */

      /* Same pattern for all checks: 
       * if previous check signalled 'ok' to run the clients and the current
       * condition is met then continue to signal 'ok' otherwise cancel running
       * and implicitely skip the next checks.
       */
      if(runcond && updateReadings(d, nrof_processors))
	runcond = 0;

      if(runcond && load){
	if(getLoadPoint() >= lmin)
	  runcond = 0;
      }

      if(runcond && users){
	if(otherUsers())
	  runcond = 0;
      }

      if(verbose && !runcond)
	printf("YASC: Start conditions are not met. Waiting...\n");

    }while(!runcond);


    /* Start condition met - run/resume the clients */
    tc = c;
    while (tc != NULL) {
      if(tc->pid == 0){ /* In case of re-running */
	if (verbose)
	  printf("YASC: Forking of child...\n");
	pid = fork();
	if (pid != 0)
	  tc->pid = pid; /* Parent */
	else 
	  run(tc); /* In child */
      }else{ /* Yepp, we have a suspendd process - resume it */
	if(verbose)
	  printf("YASC: Resuming process...\n");
	kill(tc->pid, SIGCONT);
      }
      tc = tc->next;
    }
  

    /* Check for stop condition */
    while (!updateReadings(d, nrof_processors)) {
      if(load){
	if(getLoadPoint() > lmax){ /* Load exceeded, kill/suspend */
	  if(verbose)
	    printf("YASC: Load exceeded...\n");
	  break; /* from while */
	}
      }

      if(users){
	if(otherUsers())
	  break; /* from while */
      }
      
      if(verbose)
	printf("YASC: No updates, sleeping a short while...\n");
      
      if(keepalive)
	keepAlive(c);

      sleep(6); /* We want to get rid of running processes FAST when */
    }


    /* Stop condition met - kill/suspend the clients */
    tc = c;
    if (verbose)
      printf("YASC: %s processes...\n", suspend?"Suspending":"Killing");
    while (tc != NULL) {
      if(suspend){
	kill(tc->pid, SIGSTOP);
      }else{
	kill(tc->pid, SIGTERM);
	tc->pid = 0;
	wait(NULL); /* Hocus Pocus to prevent <defunct> processes */
      }
      tc = tc->next;
    }
  } /* for(;;)  */
} /* main() */

