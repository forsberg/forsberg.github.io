
TRACEBACKDIR="/opt/lyscvs/tracebacks"
PYBIN_PREFIX="/cvsadm/"
TEMPLATE_PREFIX="/opt/lyscvs/web/templates/"
MAILTEMPLATE_PREFIX="/opt/lyscvs/mail/templates/"
SESSION_LEN = 900

DB = "nss"
USER = "web-user"
PASS = "FOO"
UNIX_SOCKET = "/var/run/mysqld/mysqld.sock"

ANON_USER = "anonymous"
CVS_HOSTNAME = "cvs.example.com"
CVS_BASEROOT = "/cvsroot"
ANON_PASSWORD = "anonymous"
ADMINISTRATOR_EMAIL = "root@example.com"

LOCAL_DOMAIN = "example.com"
MAILSERVER = 'localhost'

LOGO_ALT = "Example Logo"
LOGO_URL = "/pics/examplelogo.gif"
