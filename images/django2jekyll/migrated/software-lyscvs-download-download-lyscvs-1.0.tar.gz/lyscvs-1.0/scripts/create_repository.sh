#!/bin/sh

# Prequisities: The group _cvs_<repositoryname> must exist.

# "CVS Repository Tool"
# "(c)1999 SourceForge Development Team"
# "Released under the GPL, 1999"
# "Modified by Erik Forsberg <forsberg@lysator.liu.se> for Lysator's needs"


# if no arguments, print out help screen
if test $# -lt 1; then 
        echo "usage:"
        echo "  cvscreate.sh [repositoryname]"
        echo ""
        exit 1 
fi

# make sure this repository doesn't already exist
if [ -d /cvsroot/$1 ] ; then
        echo "$1 already exists."
        echo ""
        exit 1
fi

# first create the repository
mkdir /cvsroot/$1
/opt/lyscvs/bin/cvs -d/cvsroot/$1 init

# make it group writable
chmod 775 /cvsroot/$1

# setup loginfo to make group ownership every commit
echo "ALL chgrp -R _cvs_$1 /cvsroot/$1" > /cvsroot/$1/CVSROOT/loginfo
echo "" > /cvsroot/$1/CVSROOT/writers
echo "" > /cvsroot/$1/CVSROOT/val-tags
chmod 664 /cvsroot/$1/CVSROOT/val-tags
chown -R nobody:_cvs_$1 /cvsroot/$1

echo "Yo! This is the create_repository.sh script talking!"
echo ""
echo "Created repository $1"

# set group ownership, anonymous group user 
#chown -R nobody:$2 /cvsroot/$1
#cat /etc/passwd | grep -v anoncvs_$1 > newpasswd 
#cp newpasswd /etc/passwd
#rm -f newpasswd
#/usr/sbin/adduser -M -g $2 -d/cvsroot/$1 -s /bin/false -n anoncvs_$1



