

CREATE TABLE groups (
  group_id int(11) DEFAULT '0' NOT NULL auto_increment,
  group_name varchar(30) DEFAULT '' NOT NULL,
  group_descr varchar(255) DEFAULT '' NOT NULL,
  status char(1) DEFAULT 'A',
  PRIMARY KEY (group_id),
  KEY group_name_idx (group_name)
);

insert into groups set group_name = '_cvs_defaultgroup', group_id = 99000;

CREATE TABLE user (
  Host char(60) DEFAULT '' NOT NULL,
  User char(16) DEFAULT '' NOT NULL,
  Password char(16) DEFAULT '' NOT NULL,
  Select_priv enum('N','Y') DEFAULT 'N' NOT NULL,
  Insert_priv enum('N','Y') DEFAULT 'N' NOT NULL,
  Update_priv enum('N','Y') DEFAULT 'N' NOT NULL,
  Delete_priv enum('N','Y') DEFAULT 'N' NOT NULL,
  Create_priv enum('N','Y') DEFAULT 'N' NOT NULL,
  Drop_priv enum('N','Y') DEFAULT 'N' NOT NULL,
  Reload_priv enum('N','Y') DEFAULT 'N' NOT NULL,
  Shutdown_priv enum('N','Y') DEFAULT 'N' NOT NULL,
  Process_priv enum('N','Y') DEFAULT 'N' NOT NULL,
  File_priv enum('N','Y') DEFAULT 'N' NOT NULL,
  Grant_priv enum('N','Y') DEFAULT 'N' NOT NULL,
  References_priv enum('N','Y') DEFAULT 'N' NOT NULL,
  Index_priv enum('N','Y') DEFAULT 'N' NOT NULL,
  Alter_priv enum('N','Y') DEFAULT 'N' NOT NULL,
  PRIMARY KEY (Host,User)
);

CREATE TABLE user_group (
  user_id int(11) DEFAULT '0' NOT NULL,
  group_id int(11) DEFAULT '0' NOT NULL,
  flag char(1) DEFAULT '',
  KEY user_id_idx (user_id),
  KEY group_id_idx (group_id)
);

CREATE TABLE cmd_queue (
  id int(11) DEFAULT '0' NOT NULL auto_increment,
  user_name varchar(255) DEFAULT '' NOT NULL,
  cmd varchar(255) DEFAULT '' NOT NULL,
  args varchar(255) DEFAULT '',
  flag char(1) DEFAULT '',
  time timestamp(14),
  PRIMARY KEY (id)
);

CREATE TABLE cmd_log (
  id int(11),
  user_name varchar(255) DEFAULT '' NOT NULL,
  cmd varchar(255) DEFAULT '' NOT NULL,
  args varchar(255) DEFAULT '' NOT NULL,
  added timestamp(14),
  completed timestamp(14)
);