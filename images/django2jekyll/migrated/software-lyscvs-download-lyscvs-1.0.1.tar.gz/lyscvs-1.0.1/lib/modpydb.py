#!/usr/bin/python
# modpydb.py - Database routines for the LysCVS system
# Copyright (C) 2001 Erik Forsberg <forsberg@lysator.liu.se>
# Based on code by Gregory Trubetskoy <grisha@modpython.org>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

from constants import DB, USER, PASS, UNIX_SOCKET

import MySQLdb
import string

def _db_login(relogin = 0):
    """Login to the database
    """

    global DB_CONN

    if relogin:
        DB_CONN = MySQLdb.connect(db=DB, user=USER, passwd=PASS,
                                  unix_socket=UNIX_SOCKET)
        return DB_CONN
    else:
        try:
            d = DB_CONN
            return d

        except NameError:
            DB_CONN = MySQLdb.connect(db=DB, user=USER, passwd=PASS,
                                      unix_socket=UNIX_SOCKET)
            return DB_CONN

def run_sql(sql, param=None, n=0, with_desc=0):
    """ Runs SQL on the server and returns result
    """

    db = _db_login()

    if param:
        param = tuple(param)

    try:
        cur = db.cursor()
        rc = cur.execute(sql, param)

    except:
        # it's possible that mysql connection
        # timed out. Try one more time.
        db = _db_login(relogin = 1)
        cur = db.cursor()
        rc = cur.execute(sql, param) 

    if string.upper(string.split(sql)[0]) in \
       ("SELECT", "SHOW", "DESC", "DESCRIBE"):
        if n:
            recset = cur.fetchmany(n)
        else:
            recset = cur.fetchall()

        if with_desc:
            return recset, cur.description
        else:
            return recset
    else:
        return rc


def insert_id():
    """ Get the insert ID of the last insert
    """
    db = _db_login()
    return db.db.insert_id()
