#!/bin/sh

cd admin 
for file in add_user_to_project allow_anonymous cronjob disallow_anonymous new_external_user new_lysator_user new_repository remove_user_from_project set_user_as_admin unset_user_as_admin ; do
    ln -s ../lib/lyscvs.py $file
done


