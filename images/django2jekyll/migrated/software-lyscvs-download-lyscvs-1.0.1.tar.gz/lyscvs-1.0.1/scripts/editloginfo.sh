#!/bin/sh

# if no arguments, print out help screen
if test $# -lt 1; then 
        echo "usage:"
        echo "  editloginfo.sh <repositoryname>"
        echo ""
        exit 1 
fi

# make sure this repository doesn't already exist
if [ ! -d /cvsroot/$1 ] ; then
        echo "$1 doesn't exists."
        echo ""
        exit 1
fi

su - nobody -c "/opt/lyscvs/scripts/loginfo-cvscmds.sh $1"
chgrp -R _cvs_$1 /cvsroot/$1


echo "Done"

