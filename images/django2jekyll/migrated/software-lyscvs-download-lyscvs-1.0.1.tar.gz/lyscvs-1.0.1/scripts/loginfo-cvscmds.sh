#!/bin/sh

mkdir /tmp/cvsco.$$
cd /tmp/cvsco.$$
cvs -d /cvsroot/$1 co CVSROOT/loginfo
cd CVSROOT


echo "" >> loginfo
echo "# Please don't remove this, since it's needed for proper operation" >> loginfo
echo "ALL chgrp -R _cvs_$1 /cvsroot/$1" >> loginfo
echo >> loginfo
cvs commit -m "LysCVS modifications" loginfo
cd 
rm -rf /tmp/cvsco.$$
