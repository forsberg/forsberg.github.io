#!/usr/bin/python

import sys
import os
import os.path
import pwd

if len(sys.argv) < 2:
    print "Usage: %s <username>" % sys.argv[0]
    sys.exit(0)

if 0 != sys.argv[1].find("_cvs_"):
    print "Username must begin with '_cvs_'"
    sys.exit(1)

homepath = os.path.join("/home/", sys.argv[1])

os.umask(0)
os.mkdir(homepath, 0700)
pwnam = pwd.getpwnam(sys.argv[1])
os.chown(homepath, pwnam[2], pwnam[3])


