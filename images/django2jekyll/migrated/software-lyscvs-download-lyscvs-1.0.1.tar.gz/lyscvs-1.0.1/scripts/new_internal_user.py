#!/usr/bin/python

import sys
import os
import os.path
import nis

if len(sys.argv) < 2:
    print "Usage: %s <username>" % sys.argv[0]
    sys.exit(0)

try:
    pwnam = nis.match(sys.argv[1], "passwd").split(':')
except nis.error:
    print "Invalid local user %s" % sys.argv[1]
    sys.exit(1)

homepath = os.path.join("/home/", sys.argv[1])

os.umask(0)
os.mkdir(homepath, 0700)
os.chown(homepath, int(pwnam[2]), int(pwnam[3]))


