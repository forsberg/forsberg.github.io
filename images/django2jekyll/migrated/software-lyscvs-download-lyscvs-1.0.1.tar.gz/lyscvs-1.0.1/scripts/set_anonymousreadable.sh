#!/bin/sh

# Prequisities: The anoncvs_<repositoryname> user should be added/removed 
# from the _cvs_<repositoryname> group before this command is run.

if test $# -lt 1; then
    echo "Usage:"
    echo "  set_anonymousreadable.sh [repositoryname] [true|false]"
    echo ""
    exit 1
fi

# make sure this repository exists
if [ ! -d /cvsroot/$1 ] ; then
    echo "The repository $1 does not exist"
    echo ""
    exit 1
fi


if [ $2 == "true" ] ; then
    # turn off pserver writers, on anonymous readers
    echo "anonymous" > /cvsroot/$1/CVSROOT/readers
    echo "anonymous:\$1\$0H\$2/LSjjwDfsSA0gaDYY5Df/:anoncvs_$1" > /cvsroot/$1/CVSROOT/passwd 
    chmod 444 /cvsroot/$1/CVSROOT/readers /cvsroot/$1/CVSROOT/passwd
    chown nobody:_cvs_$1 /cvsroot/$1/CVSROOT/readers /cvsroot/$1/CVSROOT/passwd
elif [ $2 == "false" ] ; then
    echo "" > /cvsroot/$1/CVSROOT/readers
    rm -f /cvsroot/$1/CVSROOT/passwd
else 
    echo "Unknown option $2"
fi

