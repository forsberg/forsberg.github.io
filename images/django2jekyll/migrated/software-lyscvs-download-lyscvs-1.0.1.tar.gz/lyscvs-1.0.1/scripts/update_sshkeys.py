#!/usr/bin/python
# Update a users public keys

import MySQLdb
import sys
import os
import pwd

sys.path.append("/opt/lyscvs/lib")

from modpydb import run_sql
import lyscvs

if len(sys.argv) < 2:
    print "Usage: %s <username>" % sys.argv[0]
    sys.exit(255)

keys = run_sql("select version, keytext from sshkeys where uid = %d order by version" % lyscvs.lysCVS().get_user_id(sys.argv[1]))

pwnam = pwd.getpwnam(sys.argv[1])
uid = pwnam[2]
gid = pwnam[3]

os.umask(0)
homedir = os.path.join("/home/", sys.argv[1])

if not os.access(homedir, os.F_OK):
    os.mkdir(homedir, 0700)

akeys  = os.path.join(homedir, '.ssh', 'authorized_keys')
akeys2 = os.path.join(homedir, '.ssh', 'authorized_keys2')

if not os.access(os.path.join(homedir, ".ssh"), os.R_OK):
    os.mkdir(os.path.join(homedir, ".ssh"), 0700)
    os.chown(os.path.join(homedir, ".ssh"), uid, gid)


if os.access(akeys, os.R_OK):
    os.unlink(akeys)

if os.access(akeys2, os.R_OK):
    os.unlink(akeys2)

fa = None
fa2 = None

for key in keys:
    if 1 == key[0]:
        if None == fa:
            fa = open(akeys, 'w')
            fa.write("%s\n" % key[1])
    elif 2 == key[0]:
        if None == fa2:
            fa2 = open(akeys2, 'w')
            fa2.write("%s\n" % key[1])
    else:
        print "Unknown key version, %d" % key[0]

if None != fa:
    fa.close()
    os.chown(akeys, uid, gid)
    os.chmod(akeys, 0600)
if None != fa2:
    fa2.close()
    os.chown(akeys2, uid, gid)
    os.chmod(akeys2, 0600)


    
