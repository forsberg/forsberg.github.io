#!/usr/bin/python
# lyscvs.py - Support library for the LysCVS system.
# Copyright (C) 2001 Erik Forsberg <forsberg@lysator.liu.se>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

import MySQLdb
import grp
import pwd
import os
from os.path import join
from modpydb import run_sql, insert_id
from HTMLgen import TemplateDocument
import constants
import smtplib

EXT_USER_SHELL = "/opt/lyscvs/bin/cvsshell"
NSS_GROUP_CONST = 1000

class ProjectExists:
    pass

class AlreadyMemberException(Exception):
    pass

class LastAdministratorException(Exception):
    pass


class MailTemplateDocument(TemplateDocument):
    def __init__(self, template, **kw):
        self.substitutions = {}
        TemplateDocument.__init__(self,
                                  join(constants.MAILTEMPLATE_PREFIX,
                                       template) + ".mail.txt",
                                  self.substitutions, **kw)    
class lysCVS:

    def get_next_user_id(self):
        r = run_sql("select max(user_id) from user")
        ret = 100000
        try:
            ret = r[0][0] + 100000
        except TypeError:
            pass
        return ret

    def get_project_group_id(self, project):
        return grp.getgrnam("_cvs_%s" % project)[2]

    def get_user_id(self, user):
        return pwd.getpwnam(user)[2]

    def add_user_to_project(self, user, project):
        if len(run_sql("select group_id from user_group where group_id = %d and user_id = %d" % (self.get_project_group_id(project) - NSS_GROUP_CONST, self.get_user_id(user)))) > 0:
            raise AlreadyMemberException
        run_sql("insert into user_group set"+\
                  " group_id = %d, user_id = %d" % (self.get_project_group_id(project) - NSS_GROUP_CONST,
                                                    self.get_user_id(user)))

    def remove_user_from_project(self, user, project):
        run_sql("delete from user_group where"+\
                " group_id = %d and user_id = %d" % (self.get_project_group_id(project) - NSS_GROUP_CONST,
                                                    self.get_user_id(user)))

    def set_user_as_admin(self, user, project):
        run_sql("update user_group set flag = 'A' where user_id = %d and group_id = %d" % (self.get_user_id(user), self.get_project_group_id(project)-1000))

    def unset_user_as_admin(self, user, project):
        if len(run_sql("select user_id from user_group where group_id = %d and flag = 'A'" % (self.get_project_group_id(project)-NSS_GROUP_CONST))) == 1:
            raise LastAdministratorException
        run_sql("update user_group set flag = '' where user_id = %d and group_id = %d" % (self.get_user_id(user), self.get_project_group_id(project)-NSS_GROUP_CONST))
       

    def allow_anon_access_to_project(self, project):
        ni = self.get_next_user_id()
        run_sql("insert into user set user_name = 'anoncvs_%s', uid = %d, gid = %d" % (project, ni, self.get_project_group_id(project)))

    def disallow_anon_access_to_project(self, project):
        run_sql("delete from user where user_name = 'anoncvs_%s'" % project)

    def create_new_project(self, project):
        if len(run_sql("select group_name from groups where group_name = '_cvs_%s'" % project)) > 0:
            raise ProjectExists
        run_sql("insert into groups set group_name = '_cvs_%s'" % project)

    def create_local_user(self, user):
        pwn = pwd.getpwnam(user)
        res = run_sql("select user_name from user where user_name = '%s'" % user)
        if 0 == len(res):
            run_sql("insert into user set user_name = '%s', realname = '%s', uid = %d, gid = %d, email = '%s@%s'" % (pwn[0], pwn[4], pwn[2], pwn[3], pwn[0], constants.LOCAL_DOMAIN))
            SQLQueue().add_cmd('root', 'new_internal',
                               {'username':user})

    def create_external_user(self, user_name, realname, email, passwd, creating_user = 'root'):
        if 0 != user_name.find('_cvs_'):
            raise Exception("Username must begin with _cvs_")
        ni = self.get_next_user_id()
        run_sql("insert into user set user_name = '%s', realname = '%s', shell = '%s', password = ENCRYPT('%s'), uid = %d, email = '%s', homedir = '%s'" % (user_name, realname, EXT_USER_SHELL, passwd, ni, email, join("/home", user_name)))

        SQLQueue().add_cmd(creating_user, 'new_external',
                           {'username':user_name})
        T = MailTemplateDocument("new_external_user")
        T.substitutions = {'extname':realname,
                           'password':passwd,
                           'creating_email':creating_user,
                           'username':user_name,
                           'email':email}
        s = smtplib.SMTP(constants.MAILSERVER)
        s.sendmail(creating_user, [email], str(T))
        s.quit()
        

class SQLQueue:

    short_cmd_mapping = {'newrepository':
                         ['root',
                          '/opt/lyscvs/scripts/create_repository.sh',
                          ['name']],
                         'setanonymous':
                         ['root',
                          '/opt/lyscvs/scripts/set_anonymousreadable.sh',
                          ['name', 'bool']],
                         'sshkeys':
                         ['root',
                          '/opt/lyscvs/scripts/update_sshkeys.py',
                          ['username']],
                         'new_external':
                         ['root',
                          '/opt/lyscvs/scripts/new_external_user.py',
                          ['username']],
                         'new_internal':
                         ['root',
                          '/opt/lyscvs/scripts/new_internal_user.py',
                          ['username']]}

    def add_cmd(self, user, cmd, args):
        sargs = ""
        for key in self.short_cmd_mapping[cmd][2]:
            sargs+="%s:%s; " % (key, args[key])
        run_sql("insert into cmd_queue set cmd = '%s', args = '%s', user_name = '%s'" % (cmd, sargs, user))

    def execute_cmds(self):
        if 0 != os.getuid():
            raise Exception("I don't execute as root. Correct that!")
        rows = run_sql("select id, user_name, cmd, args, time from cmd_queue where flag != 'R' order by id");
        for id, user, cmd, args, timestamp in rows:
            if not self.short_cmd_mapping.has_key(cmd):
                print "Invalid command %s, id %d, please remove" % (cmd, id)
                continue
            sargs = args.strip().split(';')
            pargs = {}
            for arg in sargs[:-1]:
                (a, v) = arg.split(':')
                pargs[a.strip()] = v
            if len(pargs.keys()) != len(self.short_cmd_mapping[cmd][2]):
                print "Invalid number of arguments in argument  specification %s, please remove" % args
                continue
            rargs = ""
            try:
                for arg in self.short_cmd_mapping[cmd][2]:
                    rargs+=pargs[arg] + " "
            except KeyError:
                print "Invalid command argument specification %s, please remove" % args
                continue
            run_sql("update cmd_queue set flag = 'R' where id = %d" % id)
            os.system("%s %s" % (self.short_cmd_mapping[cmd][1],
                                 rargs))
            run_sql("insert into cmd_log set id = %d, user_name = '%s', cmd = '%s', args = '%s', added = '%s'" % (id, user, cmd, args, timestamp))
            run_sql("delete from cmd_queue where id = %d" % id)
            # XXX: Ovanst�ende funkar inte som det ska.

def GetRandomSeed():
    import random
    chr1 = int(random.random() * 52)
    chr2 = int(random.random() * 52)
    def mkletter(c):
        if 0 <= c < 26:
            c = c + 65
        if 26 <= c < 52:
            c = c - 26 + 97
        return c
    return "%c%c" % tuple(map(mkletter, (chr1, chr2)))

def gen_passwd():
    pw = ""
    for i in range(4):
        pw+=GetRandomSeed()
    return pw

def isroot():
    return 0 == os.getuid()
    
if '__main__' == __name__:
    import sys
    import os.path
    subarg = os.path.basename(sys.argv[0])
    if 'new_repository' == subarg:
        try:
            lysCVS().create_new_project(sys.argv[1])
            q = SQLQueue()
            q.add_cmd(pwd.getpwuid(os.getuid())[0], 'newrepository', {'name':sys.argv[1]})
            if isroot():
                q.execute_cmds()
        except IndexError:
            print "Usage: %s <projectname>"
    elif 'new_external_user' == subarg:
        try:
            pw = gen_passwd()
            lysCVS().create_external_user(sys.argv[1], sys.argv[2],
                                          sys.argv[3], pw)
            print "Created user %s with password %s" % (sys.argv[1], pw)
        except IndexError:
            print "Usage: %s <username> <real name> <email>" % subarg
    elif 'new_lysator_user' == subarg:
        try:
            lysCVS().create_local_user(sys.argv[1])
        except IndexError:
            print "Usage: %s <username>" % subarg
    elif 'add_user_to_project' == subarg:
        try:
            lysCVS().add_user_to_project(sys.argv[1], sys.argv[2])
        except IndexError:
            print "Usage: %s <username> <project>" % subarg
    elif 'remove_user_from_project' == subarg:
        try:
            lysCVS().remove_user_from_project(sys.argv[1], sys.argv[2])
        except IndexError:
            print "Usage: %s <username> <project>" % subarg
    elif 'set_user_as_admin' == subarg:
        try:
            lysCVS().set_user_as_admin(sys.argv[1], sys.argv[2])
        except IndexError:
            print "Usage: %s <username> <project>" % subarg
    elif 'unset_user_as_admin' == subarg:
        try:
            lysCVS().unset_user_as_admin(sys.argv[1], sys.argv[2])
        except IndexError:
            print "Usage: %s <username> <project>" % subarg
    elif 'allow_anonymous' == subarg:
        try:
            lysCVS().allow_anon_access_to_project(sys.argv[1])
            q = SQLQueue()
            q.add_cmd(pwd.getpwuid(os.getuid())[0], 'setanonymous',
                      {'name':sys.argv[1], 'bool':'true'})
            if isroot():
                q.execute_cmds()
        except IndexError:
            print "Usage: %s <project>" % subarg
    elif 'disallow_anonymous' == subarg:
        try:
            lysCVS().disallow_anon_access_to_project(sys.argv[1])
            q = SQLQueue()
            q.add_cmd(pwd.getpwuid(os.getuid())[0], 'setanonymous',
                      {'name':sys.argv[1], 'bool':'false'})
            if isroot():
                q.execute_cmds()            
        except IndexError:
            print "Usage: %s <project>" % subarg
    elif 'cronjob' == subarg:
        if isroot():
            SQLQueue().execute_cmds()
        else:
            raise Exception("cronjob needs to be executed as root")
    else:
        print "EEEEK! I don't know what you want!"
