#!/usr/bin/python

import sys
sys.path.append("/opt/lyscvs-devel/lib")
from modpydb import run_sql

def print_members(project):
    r = run_sql("select user_name, realname, email, user_group.flag from user, user_group, groups where user.uid = user_group.user_id and user_group.group_id = groups.group_id and groups.group_name = '_cvs_%s'" % project)

    if len(r) == 0:
        print "No such project or no members in project"
    else:
        print "username       Real name             email                              flag"
        print "="*76
        for user in r:
            print user[0]+' '*(15-len(user[0]))+user[1]+' '*(22-len(user[1]))+user[2]+' '*(35-len(user[2]))+user[3]

def print_projects():
    p = run_sql("select group_name from groups")
    for project in p:
        print '-'*76
        print "Members in %s" % project[0][5:]
        print_members(project[0][5:])
        print '-'*76
        print

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print_projects()
    else:
        print_members(sys.argv[1])


