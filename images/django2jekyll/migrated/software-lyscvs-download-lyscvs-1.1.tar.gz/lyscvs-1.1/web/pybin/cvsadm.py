#!/usr/bin/python
# cvsadm.py - Main file for the administration parts of LysCVS
# Copyright (C) 2001 Erik Forsberg <forsberg@lysator.liu.se>
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

from mod_python import apache
from mod_python import util
import sys
from os.path import join
import nis
import crypt
import random
from HTMLgen import *
import Cookie

sys.path.append("/opt/lyscvs/lib")

from modpydb import run_sql, insert_id
import constants
import lyscvs

# reload(lyscvs)
# reload(constants)


class User:
    def __init__(self, username):
        self.username = username
        try:
            nis.match(username, 'passwd')
            self.email = username + '@' + constants.LOCAL_DOMAIN
            self.local = 1
        except nis.error:
            self.local = 0
            self.email = run_sql("select email from user where uid = %d" % lyscvs.lysCVS().get_user_id(self.username))[0][0]
        self.projects = run_sql("select groups.group_id, groups.group_name, user_group.flag, user_group.recvmail from groups, user_group, user where groups.group_id = user_group.group_id and user_group.user_id = user.uid and user.user_name = '%s'" % username)

class Project:
    def __init__(self, projname):
        self.name = projname
        self.anonaccess = 0
        self.members = run_sql("select user_name, email, user_group.flag from user, user_group, groups where groups.group_name = '_cvs_%s' and groups.group_id = user_group.group_id and user.uid = user_group.user_id order by user_name" % self.name)

        r = run_sql("select gid from user where user_name = 'anoncvs_%s'" % self.name)
        if len(r) != 0 and int(r[0][0]) == lyscvs.lysCVS().get_project_group_id(self.name):
            self.anonaccess = 1

    def userisadmin(self, user):
        for m in self.members:
            if m[0] == user and m[2] == 'A':
                return 1
        return 0

class Authenticator:
    def __init__(self, req):
        self.cookie = None
        self.user = None
        self.session_id = -1
        self.authenticated = 0        
        self._check_status(req)

    def _check_status(self, req):
        req.add_common_vars()
        self.cookie = Cookie.SmartCookie()
        try:
            self.cookie.load(req.subprocess_env['HTTP_COOKIE'])
            try:
                id, username, r = self.cookie["session"].value.split(":")
            except ValueError:
                return
#            if r[len(r)-1] == ';':
#                r = r[:-1]
            id = int(id)
            run_sql("delete from sessions where NOW() - activestamp > %d" % 900)
            sr = run_sql("select id, NOW() - activestamp from sessions where id = %d and username = '%s' and cookie = '%s'" % (id, username, r))
            if len(sr) == 0:
                return
            else:
                self.user = User(username)
                self.authenticated = 1
                run_sql("update sessions set activestamp = NULL where id = %d" % id)
                self.session_id = id
        except KeyError:
            return

    def login(self, username, passwd):
        crypted_pass = ""
        try:
            crypted_pass = nis.match(username, 'passwd').split(':')[1]
        except nis.error:
            r = run_sql("select password from user where user_name = '%s'" % username)
            if len(r) == 0:
                return 0
            else:
                crypted_pass = r[0][0]
        if crypt.crypt(passwd, crypted_pass) == crypted_pass:
            self._login_user(username)
            return 1
        return 0

    def logout(self):
        if not self.authenticated:
            return
        run_sql("delete from sessions where id = %d" % self.session_id)
        self.cookie["session"] = ""

    # Borrowed from MailMan
    def _GetRandomSeed(self):
        chr1 = int(random.random() * 52)
        chr2 = int(random.random() * 52)
        def mkletter(c):
            if 0 <= c < 26:
                c = c + 65
            if 26 <= c < 52:
                c = c - 26 + 97
            return c
        return "%c%c" % tuple(map(mkletter, (chr1, chr2)))
    
    def _genrand(self):
        r = ""
        for i in range(40):
            r+=self._GetRandomSeed()
        return r

    def _login_user(self, username):
        r = self._genrand()
        self.user = User(username)
        run_sql("insert into sessions set username = '%s', cookie = '%s'" % (self.user.username, r))
        self.session_id = insert_id()
        self.cookie = Cookie.SmartCookie()
        self.cookie["session"] = "%d:%s:%s" % (self.session_id, self.user.username, r)
        
        
class GenericHandler:
    def __init__(self, req):
        self.req = req
        self.auth = Authenticator(req)

    def header(self, contenttype = "text/html"):
        self.req.content_type = contenttype
        if self.auth.cookie:
            self.req.headers_out["Set-Cookie"] = self.auth.cookie.output(header = "")
        self.req.send_http_header()

    def redir(self, location):
        self.req.headers_out['location'] = constants.PYBIN_PREFIX + location
        if self.auth.cookie:
            self.req.headers_out["Set-Cookie"] = self.auth.cookie.output(header = "")
        self.req.status = apache.HTTP_MOVED_TEMPORARILY
        self.req.send_http_header()
        return apache.HTTP_MOVED_TEMPORARILY

    def genmenu(self):
        t = TableLite()
        t.append(TR(TD(Image(alt=constants.LOGO_ALT, src=constants.LOGO_URL))))
        t.append(TR(TD(Href(url="mainpage", text="Main Page"))))
        if self.auth.user.local:
            t.append(TR(TD(Href(url="newproject", text="New project"))))
            t.append(TR(TD("Change password")))            
        else:
            t.append(TR(TD("New project")))
            t.append(TR(TD(Href(url="changepass", text="Change password"))))
        t.append(TR(TD(Href(url="editkeys", text = "Edit SSH keys"))))
        t.append(TR(TD(Href(url="logout", text = "Log out"))))
        return t

class MyTemplateDocument(TemplateDocument):
    def __init__(self, template, **kw):
        self.substitutions = {"nextpage":"mainpage"}
        TemplateDocument.__init__(self,
                                  join(constants.TEMPLATE_PREFIX,
                                       template) + ".tmpl.html",
                                  self.substitutions, **kw)
class Error(GenericHandler):
    def response(self, title = "Fel!", errortext = "(Ok�nt fel)"):
        T = MyTemplateDocument("error")
        T.substitutions["title"] = title
        T.substitutions["errortext"] = errortext
        if self.auth.authenticated:
            T.substitutions["menu"] = self.genmenu()
        else:
            T.substitutions["menu"] = ""
        self.req.write(str(T))
        return apache.OK
    

class LoginHandler(GenericHandler):
    def __init__(self, req, msg = "", nextpage = "mainpage"):
        GenericHandler.__init__(self, req)
        self.msg = msg
        self.nextpage = nextpage
        
    def response(self):
        self.fields = util.FieldStorage(self.req)
        T = MyTemplateDocument("login")        
        if not (self.fields.has_key("username") and self.fields.has_key("password")) :
            T.substitutions["errortext"] = self.msg
            T.substitutions["nextpage"] = self.nextpage
            if None != self.auth.user:
                T.substitutions["username"] = "\"%s\"" %self.auth.user.username
            else:
                T.substitutions["username"] = "\"\""
        elif self.auth.login(self.fields["username"], self.fields["password"]):
            nextpage = "mainpage"
            if self.auth.user.local:
                lyscvs.lysCVS().create_local_user(self.auth.user.username)
            if self.fields.has_key("nextpage"):
                nextpage = self.fields["nextpage"]
            return self.redir(nextpage)
        else:
            T.substitutions["errortext"] = "Login Failed! Try again.."
            T.substitutions["username"] = self.fields["username"]
        self.header()
        self.req.write(str(T))
        return apache.OK

class LogoutHandler(GenericHandler):
    def response(self):
        self.auth.logout()
        return self.redir("login")

class RecvMailHandler(GenericHandler):
    def response(self):
        if not self.auth.authenticated:
            return LoginHandler(self.req, msg = "You were not logged in",
                                nextpage = "mainpage").response()
        self.fields = util.FieldStorage(self.req)
        if not self.fields.has_key("project"):
            return Error(self.req).response(title = "No project", errortext = "There must be a project to change recv-mail status for!")
        thisproject = None
        for project in self.auth.user.projects:
            if project[1] == self.fields["project"]:
                thisproject = project
                break
        if None == thisproject:
            return Error(self.req).response(title="Not member", errortext = "You can't receive mail for a project you aren't member of!")
        run_sql("update user_group set recvmail = (recvmail+1)%%2 where user_id = %d and group_id = %d" % (lyscvs.lysCVS().get_user_id(self.auth.user.username), thisproject[0]))
        return self.redir("mainpage")
        
        
        

class MainPageHandler(GenericHandler):
    def projchangecode(self, project):
        return "<FORM ACTION=\"recvmailchange\" METHOD=\"POST\">"+\
               "<INPUT TYPE=SUBMIT VALUE=\"Toggle!\">"+\
               "<INPUT TYPE=HIDDEN VALUE=\"%s\" NAME=\"project\">"%project[1]+\
               "</FORM>"
    
    def response(self):
        if not self.auth.authenticated:
            return LoginHandler(self.req, msg = "You were not logged in",
                                nextpage = "mainpage").response()
        T = MyTemplateDocument("mainpage")
        T.substitutions["menu"] = self.genmenu()
        projtable = Container()
        for project in self.auth.user.projects:
            admin = "not admin"
            recvmail = "no  "
            if project[3] == 1:
                recvmail = "yes "
            name = project[1][5:]
            if project[2] == 'A':
                admin = Href(url="projadmin?project=%s" % name,
                             text = "Administrate")
            projtable.append("<TR>\n\t" + str(TD(name, align="LEFT")) + "\n\t" +\
                             str(TD(admin, align="RIGHT")) +"\n\t" +\
                             "<TD ALIGN=RIGHT>"+recvmail+"</TD>\n\t"+\
                             "<TD>"+self.projchangecode(project)+"</TD></TR>\n")
        T.substitutions["projecttable"] = projtable
        self.header()
        self.req.write(str(T))
        return apache.OK

class NewProject(GenericHandler):
    def response(self):
        if not self.auth.authenticated:
            return LoginHandler(self.req, msg = "You were not logged in",
                                nextpage = "newproject").response()
        if not self.auth.user.local:
            return Error(self.req).response(title = "Not allowed", errortext = "You must be a local user to create new projects")        
        self.fields = util.FieldStorage(self.req)
        T = MyTemplateDocument("newproject")
        T.substitutions["menu"] = self.genmenu()
        if not self.fields.has_key("projname"):
            T.substitutions["errortext"] = "&nbsp;"
        else:
            try:
                l = lyscvs.lysCVS()
                l.create_new_project(self.fields["projname"])
                l.add_user_to_project(self.auth.user.username,
                                      self.fields["projname"])
                l.set_user_as_admin(self.auth.user.username,
                                    self.fields["projname"])
                lyscvs.SQLQueue().add_cmd(self.auth.user.username,
                                          'newrepository',
                                          {'name':self.fields["projname"]})
                return self.redir("mainpage")
            except lyscvs.ProjectExists:
                T.substitutions["errortext"] = "A project with that name already exists. Try again"
        self.header()
        self.req.write(str(T))
        return apache.OK

class ProjAdmin(GenericHandler):
    def response(self):
        if not self.auth.authenticated:
            return LoginHandler(self.req, msg = "You were not logged in",
                                nextpage = "mainpage").response()
        self.fields = util.FieldStorage(self.req)
        if not self.fields.has_key("project"):
            return Error(self.req).response(title = "No project", errortext = "You must give me a project to administrate!")
        project = Project(self.fields["project"])
        if not project.userisadmin(self.auth.user.username):
            return Error(self.req).response(title = "Not administrator", errortext = "You are not administrator for the project %s" % self.fields["project"])
        T = MyTemplateDocument("projadmin")
        T.substitutions["menu"] = self.genmenu()
        T.substitutions["projname"] = self.fields["project"]
        T.substitutions["errortext"] = "&nbsp;"

        if self.fields.has_key("toggle_anon"):
            if project.anonaccess:
                lyscvs.lysCVS().disallow_anon_access_to_project(project.name)
                lyscvs.SQLQueue().add_cmd(self.auth.user.username,
                                          'setanonymous',
                                          {'name':project.name,
                                           'bool':'false'})
                return self.redir("projadmin?project=%s" % project.name)
            else:
                lyscvs.lysCVS().allow_anon_access_to_project(project.name)
                lyscvs.SQLQueue().add_cmd(self.auth.user.username,
                                          'setanonymous',
                                          {'name':project.name,
                                           'bool':'true'})
                return self.redir("projadmin?project=%s" % project.name)
        elif self.fields.has_key("remove"):
            if self.fields.has_key("username"):
                lyscvs.lysCVS().remove_user_from_project(self.fields["username"],
                                                     project.name)
            return self.redir("projadmin?project=%s" % project.name)

        elif self.fields.has_key("toggle_admin"):
            if self.fields.has_key("username"):
                if project.userisadmin(self.fields["username"]):
                    try:
                        lyscvs.lysCVS().unset_user_as_admin(self.fields["username"],
                                                            project.name)
                    except lyscvs.LastAdministratorException:
                        return Error(self.req).response(title = "Last administrator", errortext = "You are trying to remove the last administrator of the %s project - speak to the CVS server administrators (reachable as <a href=\"mailto:%s\">%s</a>) to do this." % (project.name, constants.ADMINISTRATOR_EMAIL, constants.ADMINISTRATOR_EMAIL))
                else:
                    lyscvs.lysCVS().set_user_as_admin(self.fields["username"],
                                                      project.name)
            return self.redir("projadmin?project=%s" % project.name)
        

        phtml = ""
        for member in project.members:
            administrator = 'no'
            if member[2] == 'A':
                administrator = 'yes'
            phtml+="<TR>"
            phtml+="<TD>%s</TD>" % member[0]
            phtml+="<TD ALIGN=LEFT>%s</TD>" % str(Href(url="mailto:%s" % member[1], text = "%s" % member[1]))
            phtml+="<TD ALIGN=RIGHT>%s</TD>" % administrator
            phtml+="<TD><FORM ACTION=\"projadmin\" METHOD=\"POST\">"+\
                    "<INPUT TYPE=hidden VALUE=\"%s\" NAME=\"project\">" % project.name +\
                    "<INPUT TYPE=SUBMIT VALUE=\"Toggle administration rights\" NAME=\"toggle_admin\">"+\
                    "<INPUT TYPE=HIDDEN VALUE=\"%s\" NAME=\"username\">" % member[0] +\
                    "<INPUT TYPE=SUBMIT VALUE=\"Remove\" NAME=\"remove\">"+\
                    "</FORM></TD>"
            phtml+="</TR>\n"

        T.substitutions["projmembers"] = phtml
        if project.anonaccess:
            T.substitutions["anonavail"] = 'yes'
            T.substitutions["anoninfo"] = "Use :pserver:%s@%s:%s/%s as CVSROOT and press enter when asked for a password" % (constants.ANON_USER, constants.CVS_HOSTNAME, constants.CVS_BASEROOT, project.name)
        else:
            T.substitutions["anonavail"] = 'no'
            T.substitutions["anoninfo"] = ""
        T.substitutions["cvs_hostname"] = constants.CVS_HOSTNAME
        T.substitutions["cvs_baseroot"] = constants.CVS_BASEROOT
        self.req.write(str(T))
        return apache.OK

class AddUserToProject(GenericHandler):
    def response(self):
        if not self.auth.authenticated:
            return LoginHandler(self.req, msg = "You were not logged in",
                                nextpage = "mainpage").response()            
        self.fields = util.FieldStorage(self.req)
        if not self.fields.has_key("project"):
            return Error(self.req).response(title = "No project", errortext = "You must give me a project to add a user to!")
        project = Project(self.fields["project"])
        if not project.userisadmin(self.auth.user.username):
            return Error(self.req).response(title = "Not administrator", errortext = "You are not administrator for the project %s" % self.fields["project"])
        if not self.fields.has_key("email"):
            return Error(self.req).response(title = "No email", errortext = "You must give me the email of a user to add!")
        try:
            localpart, domain = self.fields["email"].split("@")
        except ValueError:
            return Error(self.req).response(title = "Invalid email", errortext = "There is no @-sign in the mail address you gave me!")

        r = run_sql("select user_name from user where email = '%s'" % self.fields["email"])
        if len(r) == 1:
            try:
                lyscvs.lysCVS().add_user_to_project(r[0][0], project.name)
            except lyscvs.AlreadyMemberException:
                return Error(self.req).response(title = "Already member", errortext = "That user is already a member of the project. You can't add a member twice!")
            return self.redir("projadmin?project=%s" % project.name)

        if constants.LOCAL_DOMAIN == domain:
            try:
                nis.match(localpart, 'passwd')                    
            except nis.error:
                return Error(self.req).response(title = "Invalid local user", errortext = "%s is not a valid Local user" % localpart)
            lyscvs.lysCVS().create_local_user(localpart)
            try:
                lyscvs.lysCVS().add_user_to_project(localpart, project.name)
            except lyscvs.AlreadyMemberException:
                return Error(self.req).response(title = "Already member", errortext = "That user is already a member of the project. You can't add a member twice!")
            return self.redir("projadmin?project=%s" % project.name)

        if self.fields.has_key("do_add"):
            if not (self.fields.has_key("username") and self.fields.has_key("name")):
                return Error(self.req).response(title = "Not enough data", errortext = "Some data is missing. Correct that")
            if 0 != self.fields["username"].find("_cvs_"):
                return Error(self.req).response(title = "Incorrect username",
                                                errortext = "The username <B>MUST</B> begin with _cvs_ for external users")
            if len(run_sql("select user_name from user where user_name = '%s'" % self.fields["username"])) != 0:
                return Error(self.req).response(title = "Invalid user",
                                                errortext = "There is already a user with that username, choose another username")
            pw = lyscvs.gen_passwd()
            l = lyscvs.lysCVS()
            l.create_external_user(self.fields["username"],
                                                 self.fields["name"],
                                                 self.fields["email"],
                                                 pw, creating_user = self.auth.user.email)
            try:
                l.add_user_to_project(self.fields["username"], project.name)
            except lyscvs.AlreadyMemberException:
                return Error(self.req).response(title = "Already member", errortext = "That user is already a member of the project. You can't add a member twice!")                
            return self.redir("projadmin?project=%s" % project.name)

        suggested_username = "_cvs_"
        if len(run_sql("select user_name from user where user_name = '_cvs_%s'" % localpart)) == 0:
            suggested_username = "_cvs_%s" % localpart
        
        T = MyTemplateDocument("adduser")
        T.substitutions["menu"] = self.genmenu()
        T.substitutions["projname"] = project.name
        T.substitutions["email"] = self.fields["email"]
        T.substitutions["username"] = suggested_username

        self.req.write(str(T))
        
        return apache.OK

class ChangePassExternal(GenericHandler):
    def response(self):
        if not self.auth.authenticated:
            return LoginHandler(self.req, msg = "You were not logged in",
                                nextpage = "changepass").response()            
        if self.auth.user.local:
            return Error(self.req).response(title = "Not for local users",
                                            errortext = "This password change utility is not for local users - use the usual ways to change your local password")
        self.fields = util.FieldStorage(self.req)

        if self.fields.has_key("oldpass") and self.fields.has_key("newpass") and self.fields.has_key("newpass2"):
            r = run_sql("select password from  user where user_name = '%s'" % self.auth.user.username)
            if crypt.crypt(self.fields["oldpass"], r[0][0]) == r[0][0]:
                if self.fields["newpass"] != self.fields["newpass2"]:
                    return Error(self.req).response(title = "Passwords do not match",
                                                    errortext = "You didn't write your new password correct both times")
                run_sql("update user set password = '%s' where user_name = '%s'" % (crypt.crypt(self.fields["newpass"], lyscvs.gen_passwd()), self.auth.user.username))
                return self.redir("mainpage")
            else:
                return Error(self.req).response(title = "Invalid password",
                                                errortext = "You supplied an invalid old password")
            
        T = MyTemplateDocument("changepass")
        T.substitutions["menu"] = self.genmenu()
        T.substitutions["username"] = self.auth.user.username
        self.req.write(str(T))
        return apache.OK

class EditKeys(GenericHandler):
    def listkeys(self):
        return run_sql("select version, keytext from sshkeys where sshkeys.uid = %d" % lyscvs.lysCVS().get_user_id(self.auth.user.username))

    def parsekeys(self):
        try:
            lines = self.fields["sshkeys"].split("\n")
        except KeyError:
            return []
        keys = []
        for line in lines:
            version = 0
            line = line.strip()
            if '' == line:
                continue
            if -1 != line.find("ssh-dss") or -1 != line.find("ssh-rsa"):
                version = 2
            else:
                version = 1
            keys.append([version, line])
        return keys
                
    
    def response(self):
        if not self.auth.authenticated:
            return LoginHandler(self.req, msg = "You were not logged in",
                                nextpage = "editkeys").response()            
        self.fields = util.FieldStorage(self.req)
        T = MyTemplateDocument("editkeys")
        T.substitutions["msg"] = ""
        if self.fields.has_key("supdate"):
            keys = self.parsekeys()
            uid = lyscvs.lysCVS().get_user_id(self.auth.user.username)
            run_sql("update sshkeys set flag = 'C' where uid = %d" % uid)
            for key in keys:
                run_sql("insert into sshkeys set uid = %d, keytext = '%s', version = %d" % (uid, key[1], key[0]))
            run_sql("delete from sshkeys where flag = 'C' and uid = %d" % uid)
            T.substitutions["msg"] = "Keys were updated. Note that it takes up to %d minutes before changes take effect" % 15
            lyscvs.SQLQueue().add_cmd(self.auth.user.username, 'sshkeys', {'username':self.auth.user.username})

        T.substitutions["menu"] = self.genmenu()
        T.substitutions["username"] = self.auth.user.username
        tkeys = ""
        for key in self.listkeys():
            tkeys+="%s\n" % key[1]
        T.substitutions["sshkeys"] = tkeys
        self.req.write(str(T))
        return apache.OK        
        

def commandpart(uri):
    return string.split(uri, constants.PYBIN_PREFIX)[1] 

dispatchers = {"login"       : LoginHandler,
               "logout"      : LogoutHandler,
               "mainpage"    : MainPageHandler,
               "newproject"  : NewProject,
               "projadmin"   : ProjAdmin,
               "addusertoproject"     : AddUserToProject,
               "changepass"  : ChangePassExternal,
               "recvmailchange"       : RecvMailHandler,
               "editkeys"    : EditKeys }


def handler(req):
    cmdpart = commandpart(req.uri)
    try:
        response_type = dispatchers[cmdpart]
        action = response_type(req)
        return action.response()        
    except:
        import traceback
        timetext = time.strftime("%y%m%d-%H%M", time.localtime(time.time()))
        f = open(join(constants.TRACEBACKDIR, timetext), 'w')
        f.write("Time of exception: %s\n\n" % timetext)
        traceback.print_exc(file=f)
        f.write("\n")
        f.write("Remote IP: %s\n" % req.connection.remote_ip)
        f.write("Request  : %s\n" % req.the_request)
        f.close()
        f = open(join(constants.TRACEBACKDIR, timetext), 'r')
        ret = Error(req).response(title="Exception",
                                 errortext = "<PRE>%s</PRE>" % f.read())
        f.close()
        return ret

    
